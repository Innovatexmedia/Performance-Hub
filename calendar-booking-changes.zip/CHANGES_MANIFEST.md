# Booking / Calendar / Cal.com — All Changed Files

Folder structure mirrors the real project (`BACKEND/src/...`, `FRONTEND/src/...`).
Copy each file over its matching path in your project.

## BACKEND

| File | What changed |
|---|---|
| `src/app.js` | Mounted new public Cal.com booking routes (`/api/public/calcom`) before the authenticated booking routes |
| `src/modules/bookings/calcomSettings.service.js` | Fixed webhook field-name mismatch (`start` vs `startTime`), `meeting_type` enum rejecting Cal.com titles, status casing (`cancelled` vs `CANCELLED`). Added `getPublicProvider`, `listPublicEventTypes`, `listPublicSlots`, `createPublicBooking` for the real availability/booking widget |
| `src/modules/bookings/providers/calcom.provider.js` | Added real `listEventTypes()`, `getAvailableSlots()`, `createBooking()` methods (Cal.com API v2) |
| `src/modules/bookings/calcomPublicBooking.controller.js` | **New.** Public controller: list event types, list slots, create booking |
| `src/modules/bookings/calcomPublicBooking.validator.js` | **New.** Validation for the 3 public endpoints |
| `src/modules/bookings/calcomPublicBooking.routes.js` | **New.** Routes for the public booking widget |
| `src/modules/bookings/booking.controller.js` | Added `updateBooking` controller (generic edit) |
| `src/modules/bookings/booking.routes.js` | Added `PATCH /:id` route for generic edit |
| `src/modules/bookings/booking.validator.js` | Added `validateUpdateBooking` |
| `src/modules/bookings/booking.service.js` | Added `updateBooking()` service function |
| `src/modules/leads/activities/activity.model.js` | **Critical fix:** added missing `BOOKING_CREATED/COMPLETED/CANCELLED/NO_SHOW/RESCHEDULED/UPDATED` keys to `ACTIVITY_TYPE` — these were referenced by `booking.service.js` but never defined, so every booking timeline entry was silently failing validation |

## FRONTEND

| File | What changed |
|---|---|
| `src/App.tsx` | Added public route `/book/:tenantId` |
| `src/pages/Public/PublicBooking.tsx` | **New.** Public, unauthenticated Cal.com booking widget (real event types → real slots → real booking) |
| `src/lib/publicCalcomApi.ts` | **New.** API client for the public booking widget |
| `src/types/publicBooking.ts` | **New.** Types for the public booking widget |
| `src/pages/Integrations/Integrations.tsx` | Added shareable public booking link + copy button once Cal.com is connected |
| `src/pages/Bookings/Bookings.tsx` | Added Edit button/modal (generic booking edit) |
| `src/pages/Leads/LeadDrawer.tsx` | Replaced mock "Book Call" quick action with a real modal calling the real booking API |
| `src/hooks/useBookings.ts` | Added `updateBooking` |
| `src/lib/bookingsApi.ts` | Added `update()` method |
| `src/types/booking.ts` | Added `BookingUpdateInput` type |
| `src/lib/permissions.ts` | Added `canUpdate` booking permission |
| `src/hooks/usePermissions.ts` | Exposed `canUpdate` |

## Not yet run
`tsc --noEmit` / `vite build` could not be run in this sandbox (no npm registry access). Please run `npm run lint` and `npm run build` in `FRONTEND` before deploying.
