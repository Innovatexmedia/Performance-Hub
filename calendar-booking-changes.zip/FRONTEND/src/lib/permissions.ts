import type { AuthRole } from '@/types/auth';

/**
 * Frontend permission layer -- a single source of truth for "can this role
 * do X", mirroring the backend's REAL enforcement exactly (not guessed).
 * When the backend changes a role floor, this file should change with it.
 *
 * Why this exists: before this file, the only role-based UI logic anywhere
 * in the app was one boolean hiding the Super Admin nav link. Every button
 * (Add Lead, Import CSV, Archive...) rendered identically for every role,
 * and the backend's 403 was the only real guardrail -- meaning a
 * read_only_user could see and click "Delete" and only find out it was
 * blocked after the request failed.
 */

const RANK: Record<AuthRole, number> = {
  super_admin: 5,
  tenant_owner: 4,
  tenant_admin: 3,
  sales_user: 2,
  read_only_user: 1,
};

/** True if `role` is at or above `floor` in the hierarchy -- mirrors hasRole() in roles.js. */
export function atLeast(role: AuthRole | null | undefined, floor: AuthRole): boolean {
  if (!role) return false;
  return RANK[role] >= RANK[floor];
}

/**
 * Mirrors the backend's requireRoleOrPermission middleware exactly: passes
 * if EITHER the role-rank floor is met OR the specific permission was
 * individually granted. Used to decide whether to even show an
 * approve/send-type action button, not just whether the click would
 * succeed -- a user without either shouldn't see the button at all.
 */
export function hasRoleOrPermission(
  role: AuthRole | null | undefined,
  permissions: string[] | null | undefined,
  floor: AuthRole,
  permission: string,
): boolean {
  if (atLeast(role, floor)) return true;
  return (permissions || []).includes(permission);
}

/**
 * Leads permissions -- mirrors src/shared/permissions/lead.permissions.js
 * EXACTLY (the backend's own action-based matrix, not a route-floor guess):
 *
 *   super_admin / tenant_owner / tenant_admin -> everything
 *   sales_user                                -> read, create, update, assign, export (NOT delete, NOT import)
 *   read_only_user                            -> read, export ONLY
 */
export const leadPermissions = {
  canCreate: (role: AuthRole | null | undefined) => atLeast(role, 'sales_user'),
  canUpdate: (role: AuthRole | null | undefined) => atLeast(role, 'sales_user'),
  canAssign: (role: AuthRole | null | undefined) => atLeast(role, 'sales_user'),
  /** Every role including read_only_user can export -- this one is deliberately NOT gated. */
  canExport: (_role: AuthRole | null | undefined) => true,
  canDelete: (role: AuthRole | null | undefined) => atLeast(role, 'tenant_admin'),
  canImport: (role: AuthRole | null | undefined) => atLeast(role, 'tenant_admin'),
};

/**
 * Pipeline/Deal permissions -- mirrors src/shared/permissions/pipeline.permissions.js
 * EXACTLY:
 *
 *   super_admin / tenant_owner / tenant_admin -> everything
 *   sales_user                                -> read, create, update, move (NOT delete)
 *   read_only_user                             -> read ONLY
 */
export const dealPermissions = {
  canCreate: (role: AuthRole | null | undefined) => atLeast(role, 'sales_user'),
  canUpdate: (role: AuthRole | null | undefined) => atLeast(role, 'sales_user'),
  canMove: (role: AuthRole | null | undefined) => atLeast(role, 'sales_user'),
  canDelete: (role: AuthRole | null | undefined) => atLeast(role, 'tenant_admin'),
};

/**
 * Booking permissions -- mirrors booking.routes.js exactly:
 *
 *   GET routes have no requireRole() at all -- any authenticated role can read.
 *   POST /, PATCH /:id/status, POST /:id/reschedule all require sales_user+.
 *   There is NO delete/cancel endpoint on this backend at all.
 */
export const bookingPermissions = {
  canCreate: (role: AuthRole | null | undefined) => atLeast(role, 'sales_user'),
  canUpdate: (role: AuthRole | null | undefined) => atLeast(role, 'sales_user'),
  canUpdateStatus: (role: AuthRole | null | undefined) => atLeast(role, 'sales_user'),
  canReschedule: (role: AuthRole | null | undefined) => atLeast(role, 'sales_user'),
};

/**
 * Call permissions -- mirrors call.routes.js exactly:
 *   GET routes: no requireRole -- any authenticated role can read.
 *   POST /, PATCH /:id, POST /:id/ai-summary all require sales_user+.
 *   No delete endpoint exists.
 */
export const callPermissions = {
  canCreate: (role: AuthRole | null | undefined) => atLeast(role, 'sales_user'),
  canUpdate: (role: AuthRole | null | undefined) => atLeast(role, 'sales_user'),
  canRegenerateAiSummary: (role: AuthRole | null | undefined) => atLeast(role, 'sales_user'),
};

/**
 * Qualification permissions -- mirrors qualification.routes.js exactly:
 *   GET routes: no requireRole -- any authenticated role can read.
 *   POST /run, POST /:id/apply, PATCH /:id/override all require sales_user+.
 */
export const qualificationPermissions = {
  canRun: (role: AuthRole | null | undefined) => atLeast(role, 'sales_user'),
  canApply: (role: AuthRole | null | undefined) => atLeast(role, 'sales_user'),
  canOverride: (role: AuthRole | null | undefined) => atLeast(role, 'sales_user'),
};

/**
 * Campaign (marketing) permissions -- mirrors the SPEC-TRIMMED
 * campaign.routes.js exactly: only POST / (create) requires a role floor
 * (tenant_admin+). Update/delete/regenerate-link do not exist as routes
 * anymore -- removed to match spec, which names only createMarketingCampaign
 * as a write action for this module. GET routes have no requireRole -- any
 * authenticated role can read.
 */
export const campaignPermissions = {
  canCreate: (role: AuthRole | null | undefined) => atLeast(role, 'tenant_admin'),
};

/**
 * Payment permissions -- mirrors payment.routes.js exactly:
 *   GET routes: no requireRole -- any authenticated role can read.
 *   POST /, PATCH /:id, POST /:id/mark-paid, POST /:id/refund all require
 *   sales_user+. No delete endpoint exists.
 */
export const paymentPermissions = {
  canCreate: (role: AuthRole | null | undefined) => atLeast(role, 'sales_user'),
  canUpdate: (role: AuthRole | null | undefined) => atLeast(role, 'sales_user'),
  canMarkPaid: (role: AuthRole | null | undefined) => atLeast(role, 'sales_user'),
  canRefund: (role: AuthRole | null | undefined) => atLeast(role, 'sales_user'),
};

/**
 * Automation permissions -- mirrors automation.routes.js exactly:
 *   GET routes: no requireRole -- any authenticated role can read.
 *   POST / (create) and POST /:id/toggle require tenant_admin+.
 *   POST /:id/simulate requires sales_user+.
 */
export const automationPermissions = {
  canCreate: (role: AuthRole | null | undefined) => atLeast(role, 'tenant_admin'),
  canToggle: (role: AuthRole | null | undefined) => atLeast(role, 'tenant_admin'),
  canSimulate: (role: AuthRole | null | undefined) => atLeast(role, 'sales_user'),
};

/**
 * Generic Template permissions -- mirrors template.routes.js exactly:
 *   GET routes: no requireRole -- any authenticated role can read.
 *   POST / requires tenant_admin+ (scope=global additionally requires
 *   super_admin, enforced server-side and mirrored here).
 *   PATCH/DELETE require tenant_admin+ for the template's OWNER tenant,
 *   or super_admin for scope='global' templates.
 *   POST /:id/duplicate requires sales_user+.
 * These are per-resource checks (depend on the specific template's own
 * scope), not a static role floor like most other modules' permissions.
 */
export const genericTemplatePermissions = {
  canCreateTenantScope: (role: AuthRole | null | undefined) => atLeast(role, 'tenant_admin'),
  canCreateGlobalScope: (role: AuthRole | null | undefined) => role === 'super_admin',
  canEditOrDelete: (role: AuthRole | null | undefined, scope: 'tenant' | 'global') =>
    scope === 'global' ? role === 'super_admin' : atLeast(role, 'tenant_admin'),
  canDuplicate: (role: AuthRole | null | undefined) => atLeast(role, 'sales_user'),
};

/**
 * Consent permissions -- mirrors consent.constants.js's ROLE_MIN exactly
 * (see consent.routes.js, which applies each floor per-endpoint):
 *
 *   CREATE, READ, VERIFY, OPT_IN, OPT_OUT, HISTORY -> sales_user+
 *   BLOCK, UNBLOCK                                  -> tenant_admin+
 */
export const consentPermissions = {
  canCreate: (role: AuthRole | null | undefined) => atLeast(role, 'sales_user'),
  canOptIn: (role: AuthRole | null | undefined) => atLeast(role, 'sales_user'),
  canOptOut: (role: AuthRole | null | undefined) => atLeast(role, 'sales_user'),
  canBlock: (role: AuthRole | null | undefined) => atLeast(role, 'tenant_admin'),
  canUnblock: (role: AuthRole | null | undefined) => atLeast(role, 'tenant_admin'),
};

/**
 * Team permissions -- mirrors team.service.js EXACTLY, not just a static
 * role floor. Three real business rules enforced server-side that the UI
 * needs to match, or buttons would be clickable and always 403:
 *   1. Cannot change your own role / cannot deactivate your own account
 *   2. Cannot touch the tenant_owner role/status unless you ARE super_admin
 *   3. No privilege escalation -- assertCanManageRole() throws if the
 *      target role's rank >= the requester's own rank
 */
export const teamPermissions = {
  canAdd: (role: AuthRole | null | undefined) => atLeast(role, 'tenant_admin'),

  /** Can the requester change THIS member's role at all (before considering which roles to offer)? */
  canChangeRole: (requesterRole: AuthRole | null | undefined, requesterUserId: string, member: { id: string; role: AuthRole }) => {
    if (!atLeast(requesterRole, 'tenant_admin')) return false;
    if (member.id === requesterUserId) return false;
    if (member.role === 'tenant_owner' && requesterRole !== 'super_admin') return false;
    return true;
  },

  /** Which roles the requester is allowed to assign -- strictly below their own rank, matching assertCanManageRole(). */
  assignableRoles: (requesterRole: AuthRole | null | undefined): AuthRole[] => {
    if (!requesterRole) return [];
    const ceiling = RANK[requesterRole];
    return (['tenant_owner', 'tenant_admin', 'sales_user', 'read_only_user'] as AuthRole[])
      .filter((r) => RANK[r] < ceiling);
  },

  canChangeStatus: (requesterRole: AuthRole | null | undefined, requesterUserId: string, member: { id: string; role: AuthRole }) => {
    if (!atLeast(requesterRole, 'tenant_admin')) return false;
    if (member.id === requesterUserId) return false;
    if (member.role === 'tenant_owner' && requesterRole !== 'super_admin') return false;
    return true;
  },

  /** Mirrors updateMemberPermissions()'s exact guard in team.service.js. */
  canChangePermissions: (requesterRole: AuthRole | null | undefined, requesterUserId: string, member: { id: string; role: AuthRole }) => {
    if (!atLeast(requesterRole, 'tenant_admin')) return false;
    if (member.id === requesterUserId) return false;
    if (member.role === 'tenant_owner' && requesterRole !== 'super_admin') return false;
    return true;
  },
};

/**
 * Settings permissions -- mirrors settings.routes.js exactly:
 *   GET  routes -- no requireRole -- any authenticated role can view (including read_only_user).
 *   PATCH routes -- all 7 editable tabs require tenant_admin+.
 *   Lead Fields, Pipeline Stages, and Billing have no PATCH route at all (read-only/system-defined).
 */
export const settingsPermissions = {
  canEdit: (role: AuthRole | null | undefined) => atLeast(role, 'tenant_admin'),
};

/**
 * Integration permissions -- mirrors integration.routes.js exactly:
 *   GET routes -- no requireRole -- any authenticated role can view.
 *   toggle/sync/config all require tenant_admin+.
 */
export const integrationPermissions = {
  canManage: (role: AuthRole | null | undefined) => atLeast(role, 'tenant_admin'),
};

/**
 * super_admin-only gate -- used for nav visibility. This is the ONE case
 * where hiding an entire section (not just an action) is correct, because
 * Super Admin routes operate in a fundamentally different, tenant-less
 * context -- not merely "restricted", but inapplicable to any other role.
 */
export const isSuperAdmin = (role: AuthRole | null | undefined): boolean => role === 'super_admin';