import { Router } from 'express';
import * as controller from './settings.controller.js';
import {
  validateCompany,
  validateBranding,
  validateLeadFields,
  validatePipelineStages,
  validateQualification,
  validateScoringRules,
  validateNotifications,
  validateConsent,
  validateSecurity,
  validateUpdateBillingPlan,
  validateSubscribeCheckout,
  validateVerifyPayment,
} from './settings.validator.js';

import { authenticate }  from '../../shared/middlewares/auth.middleware.js';
import { resolveTenant } from '../../shared/middlewares/tenant.middleware.js';
import { requireRole }   from '../../shared/middlewares/role.middleware.js';

const router = Router();

// Auth on ALL settings routes
router.use(authenticate);
router.use(resolveTenant);

// ── Narrow, ungated cross-module reads ────────────────────────────────────────
// Deliberately NOT gated to tenant_admin -- see settings.service.js's
// comments on why these exist separately from the full, admin-gated
// settings bundle below (AI Qualification / the Pipeline board are both
// legitimately usable by sales_user+, which can't call GET /settings).
router.get('/qualification-questions', controller.getQualificationQuestions);
router.get('/pipeline-stages/board',   controller.getPipelineStagesPublic);
router.get('/branding/public',         controller.getBrandingPublic);
router.get('/currency/public',         controller.getCurrencyPublic);
router.get('/plan/public',             controller.getPlanPublic);

// ── Full settings page — GET all tabs at once ─────────────────────────────────
router.get('/', requireRole('tenant_admin'), controller.getAllSettings);

// ── Tab 1: Company ────────────────────────────────────────────────────────────
router.patch('/company',       requireRole('tenant_admin'), validateCompany,       controller.updateCompany);

// ── Tab 2: Branding ───────────────────────────────────────────────────────────
router.patch('/branding',      requireRole('tenant_admin'), validateBranding,      controller.updateBranding);

// ── Tab 3: Lead Fields (which are required) ───────────────────────────────────
router.get('/lead-fields',     requireRole('tenant_admin'), controller.getLeadFields);
router.patch('/lead-fields',   requireRole('tenant_admin'), validateLeadFields,    controller.updateLeadFields);

// ── Tab 4: Pipeline Stages (fixed keys; label/color editable) ────────────────
router.get('/pipeline-stages',   requireRole('tenant_admin'), controller.getPipelineStages);
router.patch('/pipeline-stages', requireRole('tenant_admin'), validatePipelineStages, controller.updatePipelineStages);

// ── Tab 5: Qualification Questions ───────────────────────────────────────────
router.patch('/qualification',  requireRole('tenant_admin'), validateQualification, controller.updateQualification);

// ── Tab 6: Scoring Rules ──────────────────────────────────────────────────────
router.patch('/scoring-rules',  requireRole('tenant_admin'), validateScoringRules,  controller.updateScoringRules);

// ── Tab 7: Notifications ──────────────────────────────────────────────────────
router.patch('/notifications',  requireRole('tenant_admin'), validateNotifications, controller.updateNotifications);

// ── Tab 8: Consent & Data ─────────────────────────────────────────────────────
router.patch('/consent',        requireRole('tenant_admin'), validateConsent,       controller.updateConsent);

// ── Tab 9: Billing (read-only — updated by payment webhooks) ─────────────────
router.get('/billing',          requireRole('tenant_admin'), controller.getBilling);
router.patch('/billing/plan',   requireRole('tenant_admin'), validateUpdateBillingPlan, controller.updateBillingPlan);
router.post('/billing/subscribe',        requireRole('tenant_admin'), validateSubscribeCheckout, controller.createSubscriptionCheckout);
router.post('/billing/subscribe/verify', requireRole('tenant_admin'), validateVerifyPayment, controller.verifySubscriptionPayment);

// ── Tab 10: Security ──────────────────────────────────────────────────────────
router.patch('/security',       requireRole('tenant_admin'), validateSecurity,      controller.updateSecurity);

export default router;