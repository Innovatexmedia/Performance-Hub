import { WhatsAppProvider } from './provider.interface.js';
import { normalizePhoneNumber } from '../../../shared/helpers/phone.helpers.js';

export class MetaProvider extends WhatsAppProvider {
  /**
   * @param {{ accessToken: string, phoneNumberId: string, graphApiVersion?: string }} credentials
   */
  constructor({ accessToken, phoneNumberId, graphApiVersion = 'v21.0' }) {
    super();
    if (!accessToken) throw new Error('MetaProvider requires accessToken');
    if (!phoneNumberId) throw new Error('MetaProvider requires phoneNumberId');
    this.accessToken = accessToken;
    this.phoneNumberId = phoneNumberId;
    this.graphApiVersion = graphApiVersion;
    this.baseUrl = `https://graph.facebook.com/${graphApiVersion}/${phoneNumberId}/messages`;
  }

  get name() {
    return 'meta';
  }

  /**
   * Normalizes a phone number for the Cloud API: digits only, WITH
   * country code (Meta's documented format for the `to` field).
   * Delegates to the shared normalizer -- see phone.helpers.js for why
   * this used to silently send bare 10-digit numbers with no country
   * code at all, which is one half of the duplicate-contact/wrong-number
   * bug this fixes.
   */
  static normalizePhone(phone) {
    return normalizePhoneNumber(phone);
  }

  /**
   * Browsers' MediaRecorder can only produce webm-container audio (see
   * FRONTEND Composer.tsx's voice-note recorder) -- Meta's Cloud API
   * flatly rejects that container for audio messages (confirmed live,
   * error code 131053: "Unsupported Audio mime type video/webm"; Meta
   * only accepts audio/ogg;codecs=opus, audio/mpeg, audio/amr, audio/mp4,
   * audio/aac). No browser reliably supports recording directly into any
   * of those formats via MediaRecorder, so client-side format selection
   * can't fix this alone.
   *
   * Fix: Cloudinary stores audio under its 'video' resource type (see
   * shared/services/cloudinary.service.js), which supports on-the-fly
   * format transcoding via the delivery URL -- swapping the file
   * extension to .m4a (audio-only MPEG-4, Meta-accepted as audio/mp4)
   * makes Cloudinary transcode and serve that format instead of the raw
   * upload, generated on first request and cached afterward. No ffmpeg
   * or extra infrastructure needed on our side.
   *
   * NOTE: .mp4 (not .m4a) was tried first and confirmed live NOT to
   * work -- Cloudinary's .mp4 delivery for a video-resource asset is a
   * generic video container even with no video track, so Meta correctly
   * reports it back as "video/mp4" and rejects it (error 131053, same
   * as the original .webm rejection, just a different container). .m4a
   * is the audio-only MPEG-4 variant and is what actually reports as
   * audio/mp4.
   *
   * Only rewrites .webm URLs -- anything else passes through unchanged
   * (voice notes only ever originate from our own recorder today, but
   * this stays a no-op rather than a blind rewrite if that ever changes).
   */
  static toMetaCompatibleAudioUrl(url) {
    return /\.webm(\?|$)/i.test(url) ? url.replace(/\.webm(\?|$)/i, '.m4a$1') : url;
  }

  async sendMessage({ to, content, type = 'text' }) {
    if (type !== 'text') {
      throw new Error(
        `MetaProvider: message type "${type}" is not implemented yet -- only 'text' has a real transport path. ` +
        `Sending would either fail against the Graph API or require a different request shape (media upload/link, template components) not yet built.`
      );
    }

    const body = {
      messaging_product: 'whatsapp',
      to: MetaProvider.normalizePhone(to),
      type: 'text',
      text: { body: content },
    };

    return this._post(body);
  }

  /**
   * Send a real approved WHATSAPP TEMPLATE message via the Graph API.
   * Required for every campaign/broadcast send -- Meta rejects free-text
   * business-initiated messages to a user outside an active 24h
   * customer-service session, so campaigns can never use sendMessage().
   *
   * `bodyParams` is now an array of { name, value } (see templateParams.js's
   * buildBodyParams doc comment) -- `name` is the Meta parameter_name for a
   * NAMED-format template, or null for a POSITIONAL one. Sending the wrong
   * shape for a template's actual registered format is a real, confirmed
   * bug (found at template REGISTRATION time in templateApproval.service.js's
   * buildMetaComponents, same root cause here on the send side). Only the
   * body component is populated -- header/button dynamic params aren't
   * supported yet, same "implemented only where the shape is fully
   * correct" scoping as sendMessage()'s text-only limitation above.
   */
  async sendTemplate({ to, templateName, languageCode, bodyParams = [], header }) {
    if (!templateName) throw new Error('MetaProvider.sendTemplate: templateName is required');
    if (!languageCode) throw new Error('MetaProvider.sendTemplate: languageCode is required');

    const components = [];

    // Media header component -- was completely missing before this fix,
    // so any approved template with an IMAGE/VIDEO/DOCUMENT header
    // (a real, common WhatsApp template pattern) silently failed to
    // send: Meta requires a header component whenever the approved
    // template definition HAS a media header, and there was previously
    // no code path that ever built one. Static TEXT headers need no
    // component at all (the approved text is baked into the template on
    // Meta's side already) -- only media headers need a parameter here.
    if (header?.type && header.type !== 'NONE' && header.type !== 'TEXT' && header?.mediaUrl) {
      const headerMediaType = header.type.toLowerCase(); // 'IMAGE' -> 'image', etc.
      if (!['image', 'video', 'document'].includes(headerMediaType)) {
        throw new Error(`MetaProvider.sendTemplate: unsupported header type "${header.type}"`);
      }
      components.push({
        type: 'header',
        parameters: [{ type: headerMediaType, [headerMediaType]: { link: header.mediaUrl } }],
      });
    }

    // Meta rejects a `components` array with zero-length parameters for
    // a template that has no placeholders -- so this is only included
    // when there's actually something to fill in. `parameter_name` is
    // only added when present (a NAMED-format parameter) -- omitted
    // entirely for POSITIONAL ones, matching Meta's documented send
    // payload shape for each format exactly.
    if (bodyParams.length) {
      components.push({
        type: 'body',
        parameters: bodyParams.map((p) => ({
          type: 'text',
          ...(p?.name ? { parameter_name: p.name } : {}),
          text: String(p?.value ?? p ?? ''), // `p ?? ''` fallback keeps this working if an older caller ever passes plain strings
        })),
      });
    }

    const body = {
      messaging_product: 'whatsapp',
      to: MetaProvider.normalizePhone(to),
      type: 'template',
      template: {
        name: templateName,
        language: { code: languageCode },
        ...(components.length ? { components } : {}),
      },
    };

    return this._post(body);
  }

  /**
   * Real media send via the Graph API, sent "by link" -- mediaUrl must
   * already be a durable, publicly-fetchable HTTPS URL (Cloudinary), NOT
   * something requiring auth to fetch, since Meta's own servers fetch it
   * directly. See provider.interface.js's sendMedia() doc comment.
   */
  async sendMedia({ to, mediaType, mediaUrl, caption, filename }) {
    if (!['image', 'document', 'audio'].includes(mediaType)) {
      throw new Error(`MetaProvider.sendMedia: unsupported mediaType "${mediaType}" -- only image, document, audio are implemented.`);
    }
    if (!mediaUrl) throw new Error('MetaProvider.sendMedia: mediaUrl is required');

    const effectiveUrl = mediaType === 'audio' ? MetaProvider.toMetaCompatibleAudioUrl(mediaUrl) : mediaUrl;

    const mediaObject = { link: effectiveUrl };
    // caption is valid for image/document, NOT for audio -- Meta rejects
    // the whole request if an audio object includes a caption field.
    if (caption && mediaType !== 'audio') mediaObject.caption = caption;
    // filename is only meaningful (and only accepted by Meta) for document type.
    if (filename && mediaType === 'document') mediaObject.filename = filename;
    // `voice: true` is what actually makes WhatsApp render this as the
    // native round voice-note bubble (waveform, mic icon, auto-download,
    // "played" receipts) instead of a generic playable media file --
    // confirmed via Meta's own docs, which show `voice` as a real,
    // separate field on the audio object alongside `link`. Delivery
    // format alone (the .m4a rewrite above) was NOT what controlled this
    // -- confirmed live: a working .m4a send without this flag still
    // rendered as a plain audio attachment, not a voice note.
    if (mediaType === 'audio') mediaObject.voice = true;

    const body = {
      messaging_product: 'whatsapp',
      to: MetaProvider.normalizePhone(to),
      type: mediaType,
      [mediaType]: mediaObject,
    };

    return this._post(body);
  }

  /** Shared POST + response-normalization for sendMessage/sendTemplate. */
  async _post(body) {
    // 20s timeout -- was completely unbounded before this fix, meaning a
    // single hung/slow request to Meta's API could stall this recipient's
    // job (and the worker slot processing it) forever, with no failure
    // ever occurring to trigger BullMQ's retry/backoff. This is the
    // confirmed cause of a campaign stuck at "Sending... 0/N" indefinitely
    // -- a timeout at least turns that into a real, retryable failure.
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), 20_000);

    let response;
    try {
      response = await fetch(this.baseUrl, {
        method: 'POST',
        headers: {
          Authorization: `Bearer ${this.accessToken}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(body),
        signal: controller.signal,
      });
    } catch (networkError) {
      if (networkError.name === 'AbortError') {
        throw new Error('MetaProvider: request to Graph API timed out after 20s');
      }
      throw new Error(`MetaProvider: network error calling Graph API -- ${networkError.message}`);
    } finally {
      clearTimeout(timeout);
    }

    const json = await response.json().catch(() => ({}));

    if (!response.ok) {
      const metaMessage = json?.error?.message || `HTTP ${response.status}`;
      const metaCode = json?.error?.code;
      throw new Error(`MetaProvider: send failed -- ${metaMessage}${metaCode ? ` (code ${metaCode})` : ''}`);
    }

    const providerMessageId = json?.messages?.[0]?.id || null;

    return {
      provider: 'meta',
      provider_message_id: providerMessageId,
      status: 'Sent',
      sent_at: new Date(),
      delivered_at: null,
    };
  }

  async simulateInbound() {
    throw new Error('MetaProvider does not support simulateInbound() -- inbound messages arrive via the real webhook, not simulation. This method should only ever be called on SimulationProvider.');
  }
}