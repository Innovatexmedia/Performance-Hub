/**
 * =============================================================================
 * InnovateX Revenue OS — Crypto Utilities
 * =============================================================================
 *
 * FILE: src/utils/crypto.js
 *
 * PURPOSE
 * ───────
 * AES-256-GCM symmetric encryption for storing sensitive credentials at rest.
 * Used to encrypt: WhatsApp API keys, access tokens, AI API keys, Cashfree keys
 * before saving them to MongoDB.
 *
 * HOW IT FITS
 * ───────────
 * crypto.js → Tenant.js (encrypt whatsAppSettings.accessToken, aiConfig.aiApiKey)
 *           → Integration model (encrypt per-integration credentials)
 *           → token.service.js (hash tokens for storage)
 *
 * ALGORITHM: AES-256-GCM
 * ─────────────────────
 * - 256-bit key (32 bytes)
 * - 96-bit IV (12 bytes) — randomly generated per encryption
 * - 128-bit authentication tag — prevents tampering (AEAD)
 * - IV and authTag are stored alongside the ciphertext in the DB
 *
 * STORAGE FORMAT (stored in MongoDB as a single string)
 * ──────────────────────────────────────────────────────
 * "<iv_hex>:<authTag_hex>:<ciphertext_hex>"
 *
 * ENVIRONMENT VARIABLES REQUIRED
 * ───────────────────────────────
 * ENCRYPTION_KEY — 64 hex chars (32 bytes) — generate with:
 *   node -e "console.log(require('crypto').randomBytes(32).toString('hex'))"
 *
 * ⚠️ SECURITY RULES
 * ──────────────────
 * - Never log encrypted values or the ENCRYPTION_KEY
 * - Never return encrypted values in API responses
 * - Rotate ENCRYPTION_KEY only with a full re-encryption of all stored values
 * - Never hardcode ENCRYPTION_KEY in source code
 *
 * PACKAGES REQUIRED
 * ─────────────────
 * Node.js built-in: crypto (no install needed)
 * =============================================================================
 */

import crypto from 'crypto';

const ALGORITHM  = 'aes-256-gcm';
const IV_LENGTH  = 12;  // 96-bit IV for GCM
const TAG_LENGTH = 16;  // 128-bit auth tag

/**
 * getEncryptionKey — derives a 32-byte Buffer from ENCRYPTION_KEY env var.
 * Throws clearly if the key is missing or malformed.
 * @returns {Buffer}
 */
const getEncryptionKey = () => {
  const key = process.env.ENCRYPTION_KEY;
  if (!key) {
    throw new Error(
      'ENCRYPTION_KEY environment variable is not set. ' +
      'Generate one with: node -e "console.log(require(\'crypto\').randomBytes(32).toString(\'hex\'))"'
    );
  }
  if (key.length !== 64) {
    throw new Error('ENCRYPTION_KEY must be exactly 64 hex characters (32 bytes)');
  }
  return Buffer.from(key, 'hex');
};

/**
 * encrypt — encrypts a plain-text string using AES-256-GCM.
 * Returns a colon-delimited string: "<iv>:<authTag>:<ciphertext>" (all hex).
 * @param {string} plaintext
 * @returns {string} encrypted string for storage
 */
export const encrypt = (plaintext) => {
  if (!plaintext) return null;

  const key    = getEncryptionKey();
  const iv     = crypto.randomBytes(IV_LENGTH);
  const cipher = crypto.createCipheriv(ALGORITHM, key, iv, { authTagLength: TAG_LENGTH });

  const encrypted = Buffer.concat([
    cipher.update(String(plaintext), 'utf8'),
    cipher.final(),
  ]);

  const authTag = cipher.getAuthTag();

  return `${iv.toString('hex')}:${authTag.toString('hex')}:${encrypted.toString('hex')}`;
};

/**
 * decrypt — decrypts a string previously encrypted with encrypt().
 * @param {string} encryptedString — "<iv>:<authTag>:<ciphertext>"
 * @returns {string} original plain-text value
 * @throws {Error} if decryption fails (wrong key, tampered data)
 */
export const decrypt = (encryptedString) => {
  if (!encryptedString) return null;

  const parts = encryptedString.split(':');
  if (parts.length !== 3) {
    throw new Error('Invalid encrypted string format. Expected "<iv>:<authTag>:<ciphertext>"');
  }

  const [ivHex, authTagHex, ciphertextHex] = parts;

  const key       = getEncryptionKey();
  const iv        = Buffer.from(ivHex, 'hex');
  const authTag   = Buffer.from(authTagHex, 'hex');
  const ciphertext = Buffer.from(ciphertextHex, 'hex');

  const decipher = crypto.createDecipheriv(ALGORITHM, key, iv, { authTagLength: TAG_LENGTH });
  decipher.setAuthTag(authTag);

  try {
    const decrypted = Buffer.concat([
      decipher.update(ciphertext),
      decipher.final(),
    ]);
    return decrypted.toString('utf8');
  } catch {
    throw new Error('Decryption failed — data may be tampered or the encryption key is incorrect');
  }
};

/**
 * safeDecrypt — for reading a field that started plaintext and had
 * encryption added to it LATER (every credential field touched in this
 * pass: WhatsApp settings, ad tracking Meta/Google tokens, generic
 * integration config). Any tenant's existing value saved BEFORE that
 * change shipped is genuine plaintext, not "<iv>:<authTag>:<ciphertext>"
 * -- decrypt() correctly throws on that shape, and letting it escape
 * uncaught turns every read for an already-existing tenant into a 500
 * (confirmed in practice immediately after the WhatsApp settings fix
 * went live: GET /api/whatsapp/settings started failing for a tenant
 * with pre-existing plaintext credentials). Falls back to the raw value
 * on any decrypt failure -- self-healing, since every write path
 * already encrypts unconditionally, so the field becomes real
 * ciphertext the next time this tenant saves.
 */
export const safeDecrypt = (value) => {
  if (!value) return value;
  try {
    return decrypt(value);
  } catch {
    return value;
  }
};

/**
 * hashToken — creates a SHA-256 hash of a token for safe DB storage.
 * Used for: refresh tokens, password reset tokens, email verification tokens.
 * The plain token is sent to the user; only the hash is stored in MongoDB.
 * @param {string} token
 * @returns {string} hex hash
 */
export const hashToken = (token) =>
  crypto.createHash('sha256').update(token).digest('hex');

/**
 * generateSecureToken — generates a cryptographically secure random hex token.
 * @param {number} bytes — token size in bytes (default 32 = 256-bit)
 * @returns {string} hex token
 */
export const generateSecureToken = (bytes = 32) =>
  crypto.randomBytes(bytes).toString('hex');

/**
 * generateOTP — generates a numeric OTP of specified length.
 * @param {number} digits — OTP length (default 6)
 * @returns {string}
 */
export const generateOTP = (digits = 6) => {
  const max = Math.pow(10, digits);
  const otp = crypto.randomInt(0, max);
  return String(otp).padStart(digits, '0');
};

/**
 * signState / verifySignedState — real OAuth CSRF protection for a
 * redirect-based flow, without needing a separate pending-authorization
 * DB table.
 *
 * CONFIRMED VULNERABILITY this closes (found via production audit):
 * both googleAdsOAuth.controller.js and shopifyOAuth.controller.js used
 * the RAW tenantId itself as the OAuth `state` parameter, with zero
 * signing or verification. Their own callback endpoints are
 * necessarily fully public (Google/Shopify redirect the browser here
 * directly, with no session or Authorization header) -- meaning
 * anything reachable is reachable by ANYONE, not just the tenant admin
 * who clicked "Connect". Since tenant IDs are ordinary MongoDB
 * ObjectIds (visible in URLs/API responses, not secrets), an attacker
 * could complete their OWN OAuth consent with Google/Shopify to obtain
 * a genuinely valid `code` for their OWN account, then call the
 * callback URL directly with `state=<any tenant ID they know>` --
 * no victim browser or session involved at all. The backend would
 * exchange the attacker's own code for real tokens and silently save
 * them under the VICTIM tenant, connecting the attacker's ad/Shopify
 * account to someone else's workspace (wrong dashboard data at
 * minimum; a real path to a further cross-tenant data issue if any
 * later feature ever pushes conversion/customer data back out through
 * that connection).
 *
 * Real fix: `state` is now a signed, time-limited token
 * (HMAC-SHA256 over tenantId+timestamp, keyed by the same real
 * ENCRYPTION_KEY secret already used for at-rest encryption elsewhere
 * in this codebase -- a distinct cryptographic USE of that secret, not
 * a reuse of the AES encryption itself) -- forging a state for an
 * arbitrary tenantId now requires knowing ENCRYPTION_KEY, which an
 * external attacker never has. Deliberately stateless (no new DB
 * table) so this drops into the existing buildAuthorizationUrl/
 * handleCallback functions with no schema change.
 */
const STATE_MAX_AGE_MS = 10 * 60 * 1000; // 10 minutes -- generous for a real "click Connect, go authorize" human flow, tight enough to bound replay

export const signState = (tenantId) => {
  const key = getEncryptionKey();
  const payload = `${tenantId}.${Date.now()}`;
  const signature = crypto.createHmac('sha256', key).update(payload).digest('hex');
  return Buffer.from(`${payload}.${signature}`).toString('base64url');
};

export const verifySignedState = (state) => {
  try {
    const decoded = Buffer.from(String(state), 'base64url').toString('utf8');
    const lastDot = decoded.lastIndexOf('.');
    const secondLastDot = decoded.lastIndexOf('.', lastDot - 1);
    if (lastDot === -1 || secondLastDot === -1) return null;

    const tenantId = decoded.slice(0, secondLastDot);
    const timestamp = decoded.slice(secondLastDot + 1, lastDot);
    const signature = decoded.slice(lastDot + 1);
    const payload = `${tenantId}.${timestamp}`;

    const key = getEncryptionKey();
    const expected = crypto.createHmac('sha256', key).update(payload).digest('hex');

    const expectedBuf = Buffer.from(expected);
    const receivedBuf = Buffer.from(signature);
    if (expectedBuf.length !== receivedBuf.length) return null;
    if (!crypto.timingSafeEqual(expectedBuf, receivedBuf)) return null;

    if (Date.now() - Number(timestamp) > STATE_MAX_AGE_MS) return null;

    return tenantId;
  } catch {
    return null;
  }
};